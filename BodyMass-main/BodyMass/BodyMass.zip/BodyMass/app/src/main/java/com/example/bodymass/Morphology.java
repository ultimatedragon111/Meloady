package com.example.bodymass;

public enum Morphology {
    SMALL,MEDIUM,BROAD
}
