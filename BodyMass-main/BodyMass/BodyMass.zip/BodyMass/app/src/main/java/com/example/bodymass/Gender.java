package com.example.bodymass;

public enum Gender {
    MALE,FEMALE
}
