package com.example.animations_bike;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bike extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bike);
    }
}