package com.example.bodymasskotlin;

public enum Morphology {
    SMALL,MEDIUM,BROAD
}
