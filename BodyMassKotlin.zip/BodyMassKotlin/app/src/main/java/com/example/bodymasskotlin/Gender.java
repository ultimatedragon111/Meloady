package com.example.bodymasskotlin;

public enum Gender {
    MALE,FEMALE
}