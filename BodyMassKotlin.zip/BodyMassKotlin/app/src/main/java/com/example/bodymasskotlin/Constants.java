package com.example.bodymasskotlin;

public interface Constants {
    double N_hombre = 64;
    double N_mujer = 76;
    double M_hombre = 0.75;
    double M_muujer = 0.6;
    double K_hombre = 4;
    double K_muujer = 2.5;
}
